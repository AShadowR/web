// Frontend code 
// Filename - App.js

import axios from 'axios';
import { useState } from 'react';

const App = () => {
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");

    const addData = async (e) => {
        try {
            e.preventDefault(); // Prevent form submission default behavior

            // Send a POST request with name and email data
            let result = await axios.post(
                'http://localhost:5000/register', 
                { name, email },  // Passing the data directly in the POST request
                {
                    headers: {
                        'Content-Type': 'application/json'
                    }
                }
            );

            console.warn(result);  // Log the result to see the response from the backend

            if (result.data) {
                alert("Data saved successfully");
                setEmail("");  // Clear email input
                setName("");   // Clear name input
            }
        } catch (error) {
            console.log("Error adding data", error); // Log the error
        }
    }

    return (
        <>
            <h1>This is React WebApp</h1>
            <form onSubmit={addData}> {/* Use onSubmit for the form */}
                <input 
                    type="text" 
                    placeholder="Name" 
                    value={name} 
                    onChange={(e) => setName(e.target.value)} 
                />
                <input 
                    type="email" 
                    placeholder="Email" 
                    value={email} 
                    onChange={(e) => setEmail(e.target.value)} 
                />
                <button type="submit">Submit</button>
            </form>
        </>
    );
}

export default App;
