<?php
// Start session to manage logged-in users
session_start();

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Connect to the database
    $conn = new mysqli('localhost', 'your_db_username', 'your_db_password', 'your_db_name');
    
    // Check the connection
    if ($conn->connect_error) {
        die('Connection failed: ' . $conn->connect_error);
    }

    // Prepare the SQL query to check the user's credentials
    $sql = "SELECT * FROM users WHERE email = ? OR username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ss', $email, $email); // Binding email/username to the query
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Fetch the user data from the database
        $user = $result->fetch_assoc();
        
        // Verify password
        if (password_verify($password, $user['password'])) {
            // Password is correct, set session variables and redirect to dashboard or home page
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['email'] = $user['email'];
            header('Location: index.html'); // Redirect to the homepage after login
            exit;
        } else {
            // Password is incorrect
            $_SESSION['error'] = 'Invalid password.';
            header('Location: login.html'); // Redirect back to the login page with an error message
            exit;
        }
    } else {
        // No user found
        $_SESSION['error'] = 'No user found with that email/username.';
        header('Location: login.html'); // Redirect back to the login page with an error message
        exit;
    }

    // Close the database connection
    $stmt->close();
    $conn->close();
}
?>
