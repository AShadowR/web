const loginForm = document.getElementById('loginForm');

if (loginForm) {
  loginForm.addEventListener('submit', function (e) {
    e.preventDefault();
    alert('Login successful!');
  });
}
document.addEventListener('DOMContentLoaded', function () {
  const repositories = [
    { name: 'Repo 1', url: '#', createdAt: '2024-11-30T10:00:00Z' },
    { name: 'Repo 2', url: '#', createdAt: '2024-11-29T14:30:00Z' },
    { name: 'Repo 3', url: '#', createdAt: '2024-11-28T09:15:00Z' },
    { name: 'Repo 4', url: '#', createdAt: '2024-11-29T16:00:00Z' },
    { name: 'Repo 5', url: '#', createdAt: '2024-11-27T12:00:00Z' },
    { name: 'Repo 6', url: '#', createdAt: '2024-11-26T08:30:00Z' },
    { name: 'Repo 7', url: '#', createdAt: '2024-11-25T15:00:00Z' },
    { name: 'Repo 8', url: '#', createdAt: '2024-11-24T09:45:00Z' },
  ];

  const repoList = document.getElementById('repositories');
  const searchBar = document.getElementById('searchBar');
  const prevPage = document.getElementById('prevPage');
  const nextPage = document.getElementById('nextPage');
  const pageInfo = document.getElementById('pageInfo');

  const itemsPerPage = 4;
  let currentPage = 1;

  function timeAgo(date) {
    const seconds = Math.floor((new Date() - new Date(date)) / 1000);
    const intervals = {
      year: 31536000,
      month: 2592000,
      week: 604800,
      day: 86400,
      hour: 3600,
      minute: 60,
      second: 1,
    };

    for (const [key, value] of Object.entries(intervals)) {
      const interval = Math.floor(seconds / value);
      if (interval > 1) return `${interval} ${key}s ago`;
      if (interval === 1) return `1 ${key} ago`;
    }

    return 'just now';
  }

  function displayRepositories(filteredRepos) {
    repoList.innerHTML = ''; // Clear the current list
    
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const paginatedRepos = filteredRepos.slice(startIndex, endIndex);
  
    paginatedRepos.forEach(repo => {
      const listItem = document.createElement('li');
      listItem.innerHTML = `<a href="${repo.url}">${repo.name}</a> <span>${timeAgo(repo.createdAt)}</span>`;
      repoList.appendChild(listItem);
    });
  
    pageInfo.textContent = `Page ${currentPage}`;
    prevPage.disabled = currentPage === 1;
    nextPage.disabled = endIndex >= filteredRepos.length;
  }
  
  function handleSearch() {
    const query = searchBar.value.toLowerCase();
    const filteredRepos = repositories.filter(repo =>
      repo.name.toLowerCase().includes(query)
    );
  
    currentPage = Math.min(currentPage, Math.ceil(filteredRepos.length / itemsPerPage) || 1);
    displayRepositories(filteredRepos);
  }
  

  searchBar.addEventListener('input', handleSearch);
  nextPage.addEventListener('click', () => {
    currentPage++;
    handleSearch();
  });
  
  prevPage.addEventListener('click', () => {
    currentPage--;
    handleSearch();
  });
  
  displayRepositories(repositories);
});
