<?php
// Start session to manage errors
session_start();

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Connect to the database
    $conn = new mysqli('localhost', 'your_db_username', 'your_db_password', 'your_db_name');
    
    // Check the connection
    if ($conn->connect_error) {
        die('Connection failed: ' . $conn->connect_error);
    }

    // Check if the username or email already exists
    $sql = "SELECT * FROM users WHERE username = ? OR email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ss', $username, $email); // Binding username and email to the query
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Username or email already exists
        $_SESSION['error'] = 'Username or email already exists.';
        header('Location: signup.html');
        exit;
    } else {
        // Hash the password
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);

        // Prepare the SQL query to insert the new user
        $sql = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('sss', $username, $email, $hashed_password);
        
        if ($stmt->execute()) {
            // Redirect to the login page after successful registration
            $_SESSION['success'] = 'Registration successful! Please log in.';
            header('Location: login.html');
            exit;
        } else {
            // Error occurred during insertion
            $_SESSION['error'] = 'There was an error during registration. Please try again.';
            header('Location: signup.html');
            exit;
        }
    }

    // Close the database connection
    $stmt->close();
    $conn->close();
}
?>
